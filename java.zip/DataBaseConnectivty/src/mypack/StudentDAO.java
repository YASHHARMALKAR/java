package mypack; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import java.util.Map; 
import org.springframework.jdbc.core.JdbcTemplate; 
import org.springframework.jdbc.core.RowMapper; 

public class StudentDAO { 
    private JdbcTemplate jdbcTemplate; 
    private Student obj; 

    public StudentDAO(Student obj, JdbcTemplate jdbcTemplate) { 
        this.obj = obj; 
        this.jdbcTemplate = jdbcTemplate; 
    } 

    public void insertData() { 
        int sid = obj.getStudent_id(); 
        String sname = obj.getStudent_name(); 
        int cid = obj.getCourse_id(); 
        String sql = "INSERT INTO Student(student_id, student_name, course_id) VALUES (?, ?, ?)"; 
        jdbcTemplate.update(sql, sid, sname, cid); 
        System.out.println("Record inserted successfully...!"); 
    } 

    public void deleteData() { 
        int sid = obj.getStudent_id(); 
        String sql = "DELETE FROM student WHERE student_id = ?"; 
        jdbcTemplate.update(sql, sid); 
        System.out.println("Record deleted successfully...!"); 
    } 

    public void updateData() { 
        int sid = obj.getStudent_id(); 
        String sql = "UPDATE Student SET student_name = ?, course_id = ? WHERE student_id = ?"; 
        jdbcTemplate.update(sql, obj.getStudent_name(), obj.getCourse_id(), sid); 
        System.out.println("Record updated successfully...!"); 
    } 

    public void displayData() { 
        String sql = "SELECT * FROM Student"; 
        System.out.println(jdbcTemplate.queryForList(sql)); 
    } 
}
