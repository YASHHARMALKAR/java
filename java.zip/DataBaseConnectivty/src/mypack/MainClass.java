package mypack;
  

import org.springframework.context.support.ClassPathXmlApplicationContext; 

public class MainClass { 
    public static void main(String[] args) { 
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("config.xml"); 
        StudentDAO studentDAO = (StudentDAO) context.getBean("studentdao"); 
        
        studentDAO.insertData(); 
        studentDAO.deleteData(); 
        studentDAO.updateData(); 
        studentDAO.displayData(); 
        
        context.close(); 
    } 
}

