package in.ac.famt.HelloSpringBootSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBootSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
