package in.ac.famt.HelloSpringBootSB;

import org.springframework.stereotype.Service;

@Service
public class Greeting {
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	String msg;
}
