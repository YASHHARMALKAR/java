package in.ac.famt.HelloSpringBootSB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class HelloSpringBootSbApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(HelloSpringBootSbApplication.class, args);
		System.out.println("hello world from spring boot");
		Greeting greet = context.getBean(Greeting.class);
		greet.setMsg("This is very first SB program");
		System.out.println(greet.getMsg());
	}

}
