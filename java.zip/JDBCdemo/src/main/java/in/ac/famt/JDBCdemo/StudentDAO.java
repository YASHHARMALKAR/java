package in.ac.famt.JDBCdemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StudentDAO {
	private final JdbcTemplate jdbcTemplate;
	
	@Autowired
	StudentDAO( JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public int saveStudentInfo(Student s) {
		String sqlStr="INSERT INTO Student values("+ s.getRollno()+",'"+s.getName()+"',"+ s.getMarks1()+","+ s.getMarks2()+","+ s.getMarks3()+")";
				return jdbcTemplate.update(sqlStr);
	}
	public List<Map<String,Object>> getAllStudentList() {
		String sqlStr="select * from student";
		return jdbcTemplate.queryForList(sqlStr);
	}
	public List<String>calculateTotalMarks(){
		String sqStr="select * from student";
		List<Map<String,Object>> studList = jdbcTemplate.queryForList(sqStr);
		List<String>markList= new ArrayList<String>();
		String str="";
		for(int i=0;i<studList.size();i++) {
			Map<String,Object>studElT= studList.get(i);
			int    id=    (int)  studElT.get("rollno");
			String name =(String)studElT.get("name");
			double marks1 =(double)studElT.get("marks1");
			double marks2 =(double)studElT.get("marks2");
			double marks3 =(double)studElT.get("marks3");
			
			str ="Student Detail with total marks="+id+" "+name+""+marks1+""+marks2+""+marks3;
			markList.add(str);
		}
		return markList;
	}
	
}
