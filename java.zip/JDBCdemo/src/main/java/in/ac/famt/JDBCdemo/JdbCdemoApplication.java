package in.ac.famt.JDBCdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class JdbCdemoApplication {

	public static void main(String[] args) {
		ApplicationContext Con=SpringApplication.run(JdbCdemoApplication.class,args);
 		StudentDAO studDAO=Con.getBean(StudentDAO.class);
		Student stud=new Student(8,"Pramod",12.8,45.6,87.9);
		int rowCount = studDAO.saveStudentInfo(stud);
		if(rowCount !=0) {
			System.out.println("Data saved...!");
		}
		else {
			System.out.println("Data is not saved");
		}
		System.out.println("List of the student:");
		System.out.println(studDAO.getAllStudentList());
		System.out.println(studDAO.calculateTotalMarks());
	}

}
